package com.example.magic8ball

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
